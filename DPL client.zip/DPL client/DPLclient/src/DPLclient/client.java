package DPLclient;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class client extends JFrame implements ActionListener
{

	private JLabel filenameLabel;
    private JTextField filenameField;
    private JButton Convert;
    private JPanel usernamepan, passwordpan, Buttonpan;
	private Controller controller;
	private Socket conn;
	private OutputStream output;
	private InputStream input;
     
     
    public client(Controller controller){
        
    	try{
            this.controller = controller;
            this.setLayout(new FlowLayout());
            this.initializeComponents();
            this.addComponentsToPanels();
            this.addPanelstoWindow();
            this.setWindowProperties();
            this.registerListeners();
            
			conn = new Socket(InetAddress.getLocalHost(), 9090);

		}catch(IOException ex){
			
			ex.printStackTrace();
		}
    	
    }
     
    /**
     * Initializes all components 
     */
    private void initializeComponents() 
    {
    	username = new JLabel("Username");
    	password= new JLabel("password");
 
    	usernamefield = new JTextField(10);
    	passwordfield = new JTextField(10);
         
    	Convert = new JButton("Login");
        
         
    	usernamepan = new JPanel(new FlowLayout());
    	passwordpan = new JPanel(new FlowLayout());
    	Buttonpan = new JPanel(new FlowLayout());
    }
     
    /**
     * Adds components to panels
     */
    private void addComponentsToPanels()
    {
    	usernamepan.add(username);usernamepan.add(usernamefield);
    	passwordpan.add(password);passwordpan.add(passwordfield);
    	Buttonpan.add(Convert);
        
    }
     
    /**
     * Adds Panels to the window
     */
    private void addPanelstoWindow() 
    {
        this.add(usernamepan);
        this.add(passwordpan);
        this.add(Buttonpan);
    }
 
    /**
     * Sets the default window properties
     */
    private void setWindowProperties() {
        this.setSize(250,150);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
    }
     
    /**
     * Registers all the listeners
     */
    private void registerListeners() {
    	Convert.addActionListener(this);
    }
     
     
 
    @Override
    public void actionPerformed(ActionEvent event) {
        if(event.getSource().equals(Convert)){
            String to = "";
            
            try 
            {
    			output = conn.getOutputStream();
    			input = conn.getInputStream();
    			String userpass = usernamefield.getText()+":"+passwordfield.getText();
				output.write(userpass.getBytes());//String.valueOf(usernamefield.getText()));
				
				byte [] bytes = new byte[1024];
				int read = input.read(bytes);
				//System.out.println( (char)bytes[0]);
				
				char decision=(char)bytes[0];
				
				if(decision=='1')
                {
					JOptionPane.showMessageDialog(null,"valid Password");   
                }
                else
                {
                	JOptionPane.showMessageDialog(null,"Invalid Password");
                }

				
				
			   
		    }
            catch (NumberFormatException|IOException e) 
            {
	
            }
            
      
        
    }
}

}
