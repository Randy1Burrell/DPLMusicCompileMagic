package file;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class filechoose extends JFrame implements ActionListener 
{
	JTextField fileField;
	JButton button;
	JPanel panel;
	JLabel label;
	JFileChooser filechooser;
	private Socket conn;
	private OutputStream output;
	private InputStream input;
	
	filechoose()
	{
		
        this.setLayout(new FlowLayout());
        this.initializeComponents();
        this.addComponentsToPanels();
        this.addPanelstoWindow();
        this.setWindowProperties();
        this.registerListeners();
        try {
			conn = new Socket(InetAddress.getLocalHost(), 9090);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

	private void registerListeners() 
	{
		button.addActionListener(this);
	}



	private void setWindowProperties()
	{
		    this.setSize(550,150);
	        this.setVisible(true);
	        this.setLocationRelativeTo(null);
	        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        this.setResizable(false);
	}



	private void addPanelstoWindow() 
	{
		this.add(panel);
		
	}



	private void addComponentsToPanels() 
	{
		panel.add(fileField);panel.add(button);
		
	}

   private void uploadFile()
   {
	   JFileChooser jFileChooser = new JFileChooser();
		
		jFileChooser.setCurrentDirectory(new File("/User/alvinreyes"));
		
		int result = jFileChooser.showOpenDialog(new JFrame());
		
		StringBuilder sb= new StringBuilder();
		
		    
		if (result == JFileChooser.APPROVE_OPTION) 
		{
		
		     File selectedFile = jFileChooser.getSelectedFile();
		
		     System.out.println("Selected file: " + selectedFile.getAbsolutePath());
		     
		     fileField.setText(selectedFile.getAbsolutePath());
		     
		     //java.io.File file = filechooser.getSelectedFile();
		     
		     try
		     {
		    	 FileReader fileReader = new FileReader(selectedFile.getAbsolutePath());
		    	 
		    	 BufferedReader reader = new BufferedReader(fileReader);
		    	 
		    	    String line = null;
		    	    
		    	    output = conn.getOutputStream();
	    			input = conn.getInputStream();
	    			
	    			File file =new File(selectedFile.getAbsolutePath());
	    			
	    			if(file.exists()){
	    				
	    				double bytes = file.length();
	    				
	    				 System.out.println("bytes : " + bytes);
	
	    				 String filesize=Double.toString(bytes);
	    				
	    				 output.write(filesize.getBytes());
	    				 
	    				 output.flush();
	    				 
						while ((line = reader.readLine())!=null)
						{
						    System.out.println(line);
						    output.write(line.getBytes());//String.valueOf(usernamefield.getText()));
						}
	    			}
	    			else
	    			{
	    				 System.out.println("File does not exists!");
	    			}
	    		
		    	    
	    			
					
					
					//byte [] bytes = new byte[1024];
					//int read = input.read(bytes);
		    	    
		    } 
		    catch (IOException x) 
		     {
		    	    System.err.format("IOException: %s%n", x);
		     }
		     
		     /*fileField.setText(selectedFile.getAbsolutePath());
				
				Scanner input;
				
				try 
				{
					input = new Scanner(file);
					
					while(input.hasNext())
					{
						sb.append(input.nextLine());
						
						sb.append("\n");
					}
					
					input.close();
				} 
				catch (FileNotFoundException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
				
		}
	   
   }

	private void initializeComponents() 
	{
		
		fileField= new JTextField(35);
		button=new JButton("Upload");
		panel= new JPanel();

	}
	
	public void pickMe()throws Exception
	{
		StringBuilder sb= new StringBuilder();
		if(filechooser.showOpenDialog(null)== JFileChooser.APPROVE_OPTION)
		{
			java.io.File file = filechooser.getSelectedFile();
			
			Scanner input = new Scanner(file);
			
			while(input.hasNext())
			{
				sb.append(input.nextLine());
				
				sb.append("\n");
			}
			
			input.close();
		}
		else
		{
			sb.append("No file was selected");
		}
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{

		if(event.getSource()==button)
		{
		  uploadFile();
		
	    }
	}
}
