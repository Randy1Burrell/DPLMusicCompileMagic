#include <iostream>
#include <fstream>
#include <string>
#include<cstdlib>
#include<cstring>

using namespace std;

int main()
{


	std::string line = "";

	//char* line1;

	string filename = "DPL client server only sending data from java original.txt";

	ifstream file(filename.c_str(), ifstream::in | ifstream::binary);

	if (!file.is_open())
	{
		return -1;
	}

	file.seekg(0, ios::end);
	int fileSize = file.tellg();

	printf("%d",fileSize);

	file.close();

	return 0;

}
